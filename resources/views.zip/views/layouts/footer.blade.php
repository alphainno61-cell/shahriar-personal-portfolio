<footer class="app-footer">
    <!--begin::To the end-->
    {{-- <div class="d-none d-sm-inline float-end">Anything you want</div> --}}
    <!--end::To the end-->
    <!--begin::Copyright-->
    <strong>
        Copyright &copy; 2025&nbsp;
        <a href="https://google.com" class="text-decoration-none">Shahriar</a>.
    </strong>
    All rights reserved.
    <!--end::Copyright-->
</footer>
